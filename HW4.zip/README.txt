My Name: Daniel Mann
My PID: A12863438

Partner's Name: Jared Vitug

edX Username: DAMann
email: damann@ucsd.edu

link to edX grader:
https://lifan.s3.amazonaws.com/hw3/a06f7d76591a0a5158cad65b7554d19a/20190317020257/index.html

Acceleration Structure:
 We did not have time to implement an accelration structure.

IMPORTANT NOTES ON RUNNING THE CODE:
  In this zip file I have included my program in executable form, inside of the
Release folder. The executable must be run inside that folder, becasue it needs
accsses to the FreeImage library files.
  If you wish to compile this project for yourself, I would recomend compiling it 
for release x86, as release optimizes the code greatly. I compiled the code using 
Microsoft Visual Studios 2017.

NOTES:
  I was unable to get the 6th test scene to run. Test scenes 4,5, and 7 all run though.
Because we didn't implement an acceleration structure, scene 7 takes 1 hour 30 mins to 
finish.

The test images that were submitted to edX are containted in folder "testImages".

